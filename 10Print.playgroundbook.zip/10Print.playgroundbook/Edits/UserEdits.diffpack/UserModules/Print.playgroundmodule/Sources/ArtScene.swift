import SpriteKit

public class ArtScene: SKScene{
    
    var x: CGFloat = 0
    var y: CGFloat = 0
    var w: CGFloat = 50
    var h: CGFloat = 50
    
    override public func didMove(to view: SKView) {
        self.backgroundColor = #colorLiteral(red: 0.23921568627450981, green: 0.6745098039215687, blue: 0.9686274509803922, alpha: 1.0)
        for j in 0..<50{
            for i in 0..<50{
                let prob: Int = Int.random(in: 0..<10)
                drawSymbol(char: (prob < 5) ? "/" : "A"  ,point: CGPoint(x:self.x, y:self.y))
                x += w
            }
            x = 0
            y += h
        }
    }
    
    func drawSymbol(char:String = "/", point:CGPoint){
        var p1: CGPoint = point
        var p2: CGPoint = point
        switch(char){
            case "/":
            p2.x += w
            p2.y += h
            break
            default:
            p1.y += h
            p2.x += w
            break
        }
        drawShape(points: [p1,p2])
    }
    
    func drawShape(points:[CGPoint], lineWidth:CGFloat = 3, color:UIColor = #colorLiteral(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0)){
        var shape = SKShapeNode()
        var path = CGMutablePath()
        if points.count > 0 {
            path.move(to: points[0])
            for p in points{
                path.addLine(to: p)
            }
        }
        shape.path = path
        shape.strokeColor = color
        shape.lineWidth = lineWidth
        addChild(shape)
    }
}
